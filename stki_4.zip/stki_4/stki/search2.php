<?php
include "index.php";
include "koneksi.php";
?>
<html>
	<form action='searchs2.php' method='GET'>
    	  <center> 
        	<p><font size="5" face="sans-serif"><br>
            <input type='text' size='50' name='keyword'> <input type='submit' value='Search'></font></p>
   
      </center>
      </form>
</html>