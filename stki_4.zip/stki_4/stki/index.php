<html>
<head>
<title>Sistem Temu Kembali</title>
<!--<link  href="../jw.png" rel="shortcut icon" type="image/png" />-->
<style>
h2 {
    background-size: 60px 40px;
	background-color: #c3d0ef;
}
</style>
</head>
<body>
<h2 align=center><br>SISTEM TEMU KEMBALI INFORMASI<br/> DOKUMEN TEMA BERITA SEPAK BOLA MENGGUNAKAN ALGORITMA MEAN-MEANHATTAN <br><br></h2>
<hr>
<div align=center>
| <a href="koneksi.php">Koneksi</a> |
<a href="buatberita.php">Buat Dokumen</a> |
<a href="lihatberita.php">Lihat Dokumen</a> |
<a href="lowercase.php">Lower Case Dokumen</a> |
<a href="hapustandabaca.php">Hapus Tanda Baca</a> |
<a href="tokenisasi.php">Tokenisasi Kata</a> |
<a href="hasiltokenisasikata.php">Hasil Token Kata</a> |
<a href="datastopword.php">Data Stopword</a> |
<a href="prosesstopword.php">Proses Stopword</a> |
<a href="prosesstemming.php">Proses Stemming</a> |
<a href="tf.php">Term Frequency</a> |
<a href="idf.php">Invers Document Frequency</a> |
<a href="tfidf.php">TF.IDF</a> |
<a href="search.php">Tfidf1</a> |
<a href="search1.php">Tfidf2</a> |
<a href="search2.php">Tfidf3</a> |
<a href="searchmeanmanhattan1.php">meanmanhattan1</a> |
<a href="searchmeanmanhattan2.php">meanmanhattan2</a> |
<a href="searchmeanmanhattan3.php">meanmanhattan3</a> |
</div>
<hr/>
</body>
</html>
